"""Vérifications déterministes (sans IA) appliquées aux réponses et aux saisies.

Pourquoi en code : compter des mots, repérer « ne… pas » ou mesurer la répétition
entre phrases est plus fiable côté script que côté modèle. Ces règles sont simples
volontairement, pour que les développeurs puissent les porter en JS à l'identique.
"""
from __future__ import annotations

import re
import unicodedata

# --- Bornes de longueur (prompt de la maquette : 10 à 20 mots par phrase) -------------
MOTS_MIN = 10
MOTS_MAX = 20
# Deux phrases ne doivent pas partager plus de ce nombre de mots pleins.
CHEVAUCHEMENT_MAX = 1

# Un mot = suite de lettres/chiffres ; l'apostrophe et le trait d'union restent dans le mot
# (« j'atteins » = 1 mot, comme dans Word).
_MOT = re.compile(r"[\wÀ-ÿ]+(?:['’\-][\wÀ-ÿ]+)*")
_PIECE = re.compile(r"[\wÀ-ÿ]+")

# Négation grammaticale : « ne / n' » suivi (à 2 mots près) de pas, plus, jamais, rien…
_NEGATION = re.compile(
    r"\b(?:ne\s+|n['’]\s*)(?:[\wÀ-ÿ'’\-]+\s+){0,2}?(?:pas|plus|jamais|rien|aucun|aucune|guère|point)\b",
    re.IGNORECASE)

# Verbes de contrainte : formes conjuguées de vouloir / devoir / falloir.
# « pouvoir » est volontairement exclu : le livret recommande « Je peux… » (cf. savoir_motto.md).
_CONTRAINTE = re.compile(
    r"\b(?:il\s+(?:(?:ne|me|te|lui|nous|vous|leur)\s+|m['’]|t['’]|n['’])?(?:faut|faudrait|faudra)"
    r"|falloir|je\s+(?:dois|devrais|me\s+dois|veux|voudrais))\b",
    re.IGNORECASE)

_PREMIERE_PERSONNE = re.compile(r"\b(?:je|j['’])", re.IGNORECASE)

# Filet de sécurité (pas un outil clinique) : expressions explicites de détresse.
# Liste courte et prudente, à faire relire par des professionnels du Vinatier.
_DETRESSE = re.compile(
    r"suicid|me\s+tuer|me\s+supprimer|me\s+foutre\s+en\s+l'air|mettre\s+fin\s+[àa]\s+(?:mes\s+jours|ma\s+vie)"
    r"|envie\s+d'en\s+finir|veux\s+en\s+finir|vais\s+en\s+finir|en\s+finir\s+avec\s+(?:la\s+vie|tout)"
    r"|plus\s+envie\s+de\s+vivre|plus\s+de\s+raison\s+de\s+vivre|envie\s+de\s+mourir"
    r"|(?:veux|voudrais|aimerais)\s+(?:juste\s+)?mourir|me\s+faire\s+du\s+mal|disparaître\s+pour\s+toujours",
    re.IGNORECASE)

_STOP = set("""
le la les un une des du de d l à au aux en et ou où que qui qu quoi dont dans sur sous avec par pour sans vers chez
ce cet cette ces se s ne n pas plus mon ma mes ton ta tes son sa ses notre nos votre vos leur leurs
je j tu il elle on nous vous ils elles me m te t moi toi lui y
est suis es sommes êtes sont ai as a avons avez ont être avoir été
comme mais donc or ni car si aussi tout toute tous toutes très bien même
""".split())


# --- Emojis et pictogrammes (interdits dans les réponses du modèle) -----------------------
# Blocs Unicode des emojis et pictogrammes courants. Les flèches simples (→ ←), les guillemets « »,
# « … », ©, ® et ™ ne sont volontairement PAS dans la liste.
_EMOJI = re.compile(
    "[\U0001F000-\U0001FAFF"    # émoticônes, symboles, transports, drapeaux, pictogrammes étendus
    "\U00002600-\U000027BF"      # symboles divers et dingbats (coches, croix, étoiles, soleil...)
    "\U00002B00-\U00002BFF"      # flèches et symboles divers (étoile, cercles, carrés)
    "\U0000231A-\U0000231B\U000023E9-\U000023FA"   # montre, sablier, lecteur, alarme
    "\U0000203C\U00002049"       # !! et !?
    "\U0000FE0F\U0000200D\U000020E3]")   # sélecteur d'emoji, liaison, keycap


def contient_emoji(texte: str) -> bool:
    return bool(_EMOJI.search(texte or ""))


def retirer_emojis(texte: str) -> str:
    """Supprime les emojis et nettoie les espaces laissés (le reste du texte est intact)."""
    propre = _EMOJI.sub("", texte or "")
    propre = re.sub(r"[ \t]{2,}", " ", propre)
    return re.sub(r" +([,.])", r"\1", propre).strip()     # pas « ; : ! ? » : l'espace est française


def _sans_accents(texte: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", texte) if unicodedata.category(c) != "Mn")


_STOP_NORM = {_sans_accents(s) for s in _STOP}


SEGMENT_MOTS_MAX = 6    # un segment cliquable = un mot ou une courte expression


def texte_depuis_segments(segments: list[str]) -> str:
    """Phrase reconstituée : segments recollés dans l'ordre, séparés par une espace."""
    return " ".join(s.strip() for s in segments if s.strip())


def compter_mots(texte: str) -> int:
    return len(_MOT.findall(texte))


def trouver_negation(texte: str) -> str | None:
    m = _NEGATION.search(texte)
    return m.group(0) if m else None


def trouver_contrainte(texte: str) -> str | None:
    m = _CONTRAINTE.search(texte)
    return m.group(0) if m else None


def a_premiere_personne(texte: str) -> bool:
    return bool(_PREMIERE_PERSONNE.search(texte))


def detecter_detresse(*textes: str) -> bool:
    return any(_DETRESSE.search((t or "").replace("’", "'")) for t in textes)


def mots_pleins(texte: str) -> set[str]:
    """Mots porteurs de sens (hors mots-outils), sans accents ni pluriel simple."""
    resultat = set()
    for piece in _PIECE.findall(_sans_accents(texte).lower()):
        if piece in _STOP_NORM or len(piece) <= 2:
            continue
        resultat.add(piece[:-1] if len(piece) > 3 and piece[-1] in "sx" else piece)
    return resultat


def chevauchements(phrases: list[str]) -> list[tuple[int, int, list[str]]]:
    """Paires de phrases qui partagent plus de CHEVAUCHEMENT_MAX mots pleins."""
    ensembles = [mots_pleins(p) for p in phrases]
    exces = []
    for i in range(len(phrases)):
        for j in range(i + 1, len(phrases)):
            commun = sorted(ensembles[i] & ensembles[j])
            if len(commun) > CHEVAUCHEMENT_MAX:
                exces.append((i + 1, j + 1, commun))
    return exces


def verifier_phrase_motto(phrase: str, *, bornes: bool = True) -> list[str]:
    """Écarts mécaniques d'une phrase de motto (liste vide = rien à signaler)."""
    p = []
    if bornes:
        n = compter_mots(phrase)
        if not MOTS_MIN <= n <= MOTS_MAX:
            p.append(f"compte {n} mots (attendu : de {MOTS_MIN} à {MOTS_MAX})")
    if (neg := trouver_negation(phrase)):
        p.append(f"contient une négation (« {neg} »)")
    if (contr := trouver_contrainte(phrase)):
        p.append(f"contient une formule de contrainte (« {contr} »)")
    if not a_premiere_personne(phrase):
        p.append("n'est pas écrite à la première personne (« je »)")
    return p
