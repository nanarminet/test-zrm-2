{{REGLES_COMMUNES}}

{{SAVOIR_MOTTO}}

# Ta tâche : le panier à idées du motto
À partir de l'image choisie par l'apprenant (si elle est jointe à ce message : consulte-la sans la décrire), de ses idées favorites et de son souhait, propose EXACTEMENT 5 phrases qui pourraient devenir son motto.

Contraintes pour chaque phrase :
- elle respecte les 10 critères de formulation du motto ;
- elle compte entre 10 et 20 mots ;
- elle est écrite à la première personne, au présent, comme une invitation, une incitation ou une autorisation ;
- elle utilise un langage simple, imagé, poétique, rythmé ;
- elle ne contient aucune négation (« ne… pas », « jamais », « plus »…) ni aucun mot négatif ;
- elle reste proche de l'image, des idées favorites et du souhait de l'apprenant : sois créatif, mais ne t'en éloigne pas.

Diversité (essentielle : l'apprenant doit pouvoir choisir) : les 5 phrases utilisent des mots et des expressions différents. Aucun nom, verbe, adjectif ou expression ne se retrouve dans deux phrases ; seuls les petits mots de liaison et « je », « mon », « ma », « mes » peuvent se répéter. Varie aussi les débuts de phrase, les verbes et le rythme. Répartis les idées favorites de l'apprenant entre les phrases au lieu de toutes les mettre dans chacune.

Découpage en segments : l'apprenant va cliquer sur les mots et expressions qui lui parlent à l'intérieur de chaque phrase. Tu fournis donc chaque phrase découpée en segments, dans l'ordre :
- de 3 à 8 segments par phrase ; un segment est un mot porteur de sens ou une courte expression (1 à 5 mots), qu'on a envie de retenir ou de laisser ;
- la ponctuation reste collée au segment qui la précède (« Avec tendresse, ») ; une élision reste dans son segment (« je m'autorise ») ;
- si on recolle les segments dans l'ordre, séparés par un espace, on obtient exactement la phrase, sans rien ajouter ni retirer ;
- dans une même phrase, deux segments ne sont jamais identiques.

# Format de sortie (JSON)
{
  "phrases": [
    {"segments": ["…", "…", "…"]},
    {"segments": ["…", "…", "…"]},
    {"segments": ["…", "…", "…"]},
    {"segments": ["…", "…", "…"]},
    {"segments": ["…", "…", "…"]}
  ],
  "detresse": false
}
