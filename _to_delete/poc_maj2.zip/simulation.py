"""Réponses SIMULÉES (LLM_PROVIDER=mock) : aucune IA n'est appelée.

Sert uniquement à essayer l'interface et à tester le code sans clé. Les contenus
sont figés et ne disent rien de la qualité réelle du modèle.
"""
from __future__ import annotations

import json

import schemas
from llm import Reponse

_PHRASES = [
    {"segments": ["Je m'autorise", "à me balader librement", "sur mon îlot", "de lumière douce."]},
    {"segments": ["Avec tendresse,", "je cultive", "mes valeurs", "et j'ouvre grand", "mes fenêtres", "au vent."]},
    {"segments": ["Je savoure", "chaque matin", "le chant joyeux", "de mon jardin", "intérieur."]},
    {"segments": ["Porté par la vague,", "je danse", "avec confiance", "au rythme", "de mon souffle."]},
    {"segments": ["Je m'offre", "un regard curieux", "et j'accueille", "la beauté", "des petites choses."]},
]

_DONNEES = {
    "propositions_motto": {"phrases": _PHRASES, "detresse": False},
    "verification_motto": {
        "criteres": {i: {"respecte": True, "explication": ""} for i in schemas.IDS_CRITERES},
        "suggestion": "Je cultive le calme et je m'ouvre à la douceur de mon jardin intérieur.",
        "detresse": False},
    "aide_memoire": {
        "fixes": [{"idee": "l'image du motto aimantée sur le frigo", "categorie": "objet"},
                  {"idee": "un fond d'écran apaisant sur l'ordinateur de bureau", "categorie": "objet"},
                  {"idee": "une bougie au parfum de pin posée sur le bureau, avec un ruban ajouté", "categorie": "odeur"},
                  {"idee": "un carillon à vent accroché près de la fenêtre", "categorie": "musique"}],
        "mobiles": [{"idee": "un porte-clés en forme de plume", "categorie": "objet"},
                    {"idee": "un marque-page orné d'un petit dessin du paysage", "categorie": "objet"},
                    {"idee": "un fond d'écran du paysage sur le téléphone", "categorie": "objet"},
                    {"idee": "la sonnerie du téléphone remplacée par un chant d'oiseau", "categorie": "musique"}],
        "detresse": False},
    "mouvements": {
        "macro": ["ouvrir grand les bras comme des ailes", "tourner lentement le haut du corps",
                  "lever les bras au-dessus de la tête en respirant"],
        "micro": ["poser les mains sur les genoux", "bouger ses doigts les uns après les autres",
                  "relâcher les épaules en expirant"],
        "detresse": False},
}


def reponse_simulee(nom: str, messages: list[dict]) -> Reponse:
    donnees = _DONNEES[nom]
    return Reponse(donnees=json.loads(json.dumps(donnees)), brut=json.dumps(donnees, ensure_ascii=False),
                   usage={"prompt_tokens": 0, "completion_tokens": 0}, latence_s=0.0, format_utilise="simulation")
